# Tools: Giving Your Agent Real-World Superpowers

*Part 3 of the LangChain Made Easy series*

Ok, so in the first post of this series, we built an agent using `create_agent()` and gave it a tool called `get_weather`. That was one way to hand a model a tool. But here's the thing, that's not the only way. You can actually give tools directly to a model too, without wrapping everything inside `create_agent()`.

In this post, we're going deep into Tools. What they are, how to create them properly, and two different ways to actually use them. Let's get into it.

---

## So, what exactly is a tool?

Think of a tool as a regular Python function that you hand over to the model, and say "hey, use this whenever you need it." The model itself doesn't run your Python code. It just decides when a tool is needed, and with what input, then your code runs it and hands the result back.

Tools can do pretty much anything you can code:

- Fetch live data from an API (weather, stock prices, news)
- Query a database
- Do a calculation the model can't reliably do on its own
- Even call another LLM

```mermaid
graph LR
    A["User asks a question"] --> B[Model]
    B -- "Decides a tool is needed" --> C[Your Tool Function]
    C -- "Runs and returns result" --> B
    B --> D["Final answer to user"]
```

Simple enough, right? Now let's actually build one.

---

## Creating a tool

Here's the entire recipe. You write a normal Python function, and slap a `@tool` decorator on top of it.

```python
from langchain.tools import tool

@tool
def get_current_weather(location: str) -> str:
    """
    Get the current weather for a given location.
    """
    return f"The current weather in {location} is 25°C and sunny."
```

That's it. That `@tool` decorator is doing the heavy lifting here, it converts your plain function into something the model can understand and call.

Now, remember what we said in Post 1 about docstrings? Same rule applies here, and honestly it matters even more now. The docstring is not a comment for your teammates to read later. It is literally what the model reads to decide "should I use this tool right now, or not?"

| What you write in the docstring | What the model does with it |
|---|---|
| Vague or missing | Model might ignore the tool, or call the wrong one |
| Clear and specific | Model calls it confidently, at the right time |

So don't treat the docstring as an afterthought. Write it like you're explaining the tool to someone who has never seen your code.

---

## Let's create a few more tools

One tool is boring. Let's make three, so the model actually has to think about which one fits the question.

```python
@tool
def get_current_weather_tool(location: str) -> str:
    """
    Get the current weather in a given location
    """
    return f"The current weather in {location} is sunny with a temperature of 25°C."

@tool
def get_stock_price_tool(stock_symbol: str) -> str:
    """
    Get the current stock price of a given stock symbol
    """
    return f"The current stock price of {stock_symbol} is $150."

@tool
def get_news_tool(topic: str) -> str:
    """
    Get the latest news on a given topic
    """
    return f"The latest news on {topic} is that the stock market is up by 2% today."
```

Notice each one does something completely different, weather, stock prices, news. That's on purpose. In a bit, we'll ask the model questions and watch it pick the correct tool on its own.

---

## Now, the interesting part: binding tools directly to a model

In Post 1, we passed tools into `create_agent()`, and the agent handled everything behind the scenes. But what if you don't want a full agent? What if you just want a plain chat model that can call tools when needed?

That's where `bind_tools()` comes in.

```python
import os
from dotenv import load_dotenv
from langchain.chat_models import init_chat_model

load_dotenv(override=True)

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["GOOGLE_API_KEY"] = os.getenv("GOOGLE_API_KEY")
os.environ["GROQ_API_KEY"] = os.getenv("GROQ_API_KEY")

google_model_name = os.getenv("GOOGLE_MODEL")
google_model = init_chat_model(
    google_model_name,
    model_provider="google_genai"
)

google_model_with_tools = google_model.bind_tools(
    [get_current_weather_tool, get_stock_price_tool, get_news_tool]
)
```

What's happening here? We took a plain chat model, `google_model`, and called `.bind_tools()` on it, passing in our list of tools. Now this new object, `google_model_with_tools`, knows those three tools exist and can decide to use them whenever it needs to.

So basically, this is the "lighter" way of giving a model tool access, no full agent setup required.

---

## Ok, now what? Let's actually test it

Here's where it gets fun. We'll ask three completely different questions and watch what the model decides to do each time.

```python
tool_response = google_model_with_tools.invoke("What is the current weather in New York?")
print(tool_response.type)  # ai

tool_calls = tool_response.tool_calls

if tool_calls:
    for tool_call in tool_calls:
        print(f"Tool: {tool_call['name']}")
        print(f"Args: {tool_call['args']}")
else:
    print("No tool calls were made for this response.")
```

Run this, and you'll see the model correctly picks `get_current_weather_tool`, with `location` set to `New York`. It didn't guess. It matched the question against the docstrings of all three tools and picked the one that actually fits.

Let's try another one.

```python
tool_response = google_model_with_tools.invoke("What is the current stock price of PYPL?")

tool_calls = tool_response.tool_calls

if tool_calls:
    for tool_call in tool_calls:
        print(f"Tool: {tool_call['name']}")
        print(f"Args: {tool_call['args']}")
else:
    print("No tool calls were made for this response.")
```

This time it picks `get_stock_price_tool`, with `stock_symbol` set to `PYPL`. Notice how it also figured out the right argument name and value from a plain English question. That's not magic, it's the model reading your function's type hints and docstring together.

And here's a fun one to try.

```python
tool_response = google_model_with_tools.invoke("Who won the IPL-2025?")

tool_calls = tool_response.tool_calls

if tool_calls:
    for tool_call in tool_calls:
        print(f"Tool: {tool_call['name']}")
        print(f"Args: {tool_call['args']}")
else:
    print("No tool calls were made for this response.")
```

What do you think happens here? We don't have a tool for IPL match results, only weather, stock, and news. So depending on the model, it might either call `get_news_tool` with `topic` set to something like "IPL 2025" since that is the closest fit, or it might make no tool call at all and just answer from its own memory. Either way, this shows you something important: the model only picks from what you gave it. If none of your tools genuinely fit, don't expect a miracle.

---

## Two ways to use tools, side by side

Let's put both approaches next to each other, since it's easy to mix them up as a beginner.

| Approach | How you use it | When it fits best |
|---|---|---|
| `create_agent(tools=[...])` | Wraps everything into a ready-made agent loop | You want a full conversational agent that handles multiple turns and tool calls automatically |
| `model.bind_tools([...])` | Attaches tools directly to a plain chat model | You want more control, or you're only doing a single tool-calling step yourself |

Neither one is "better." It really depends on how much control you want versus how much you want LangChain to handle for you.

```mermaid
graph TD
    A[Your Tools] --> B{How do you want to use them?}
    B -- "Full agent behavior" --> C["create_agent(tools=[...])"]
    B -- "Direct model control" --> D["model.bind_tools([...])"]
    C --> E["Agent decides, calls tool, responds automatically"]
    D --> F["Model returns a tool_call, you decide what happens next"]
```

Notice the difference in that last box. With `bind_tools()`, the model just tells you which tool it wants to call and with what arguments, it does not actually run the tool for you. You are responsible for executing the function yourself and feeding the result back if needed. With `create_agent()`, all of that is handled automatically behind the scenes.

---

## One thing worth repeating

We've said this before, but it deserves repeating here: the model is not reading your code. It is reading your docstring, your function name, your parameter names, and your type hints. That's the entire "instruction manual" it has.

So a quick checklist before you ship any tool:

- Does the function name clearly describe what it does?
- Does the docstring explain exactly when to use it?
- Are the parameter names and types clear (`location: str`, not `x: str`)?
- Would a stranger reading only the docstring know when to call this?

If you can say yes to all four, your tool is production ready.

---

## Recap

- A tool is just a Python function decorated with `@tool`, that a model can choose to call.
- The docstring is what tells the model what the tool does and when to use it, so write it carefully.
- You can bind tools directly to a model using `bind_tools()`, without needing a full agent.
- The model reads your question, compares it against every tool's docstring, and picks the best match, or none at all if nothing fits.
- `create_agent()` and `bind_tools()` both work, just at different levels of control.

Not bad, right? You now know two solid ways to give your model real world abilities.

---

**Coming up next:** we'll look at Messages, the actual format models use to understand conversations, and why getting this right matters more than most beginners realize.
