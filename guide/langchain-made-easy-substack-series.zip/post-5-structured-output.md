# Structured Output: Getting Predictable Data from LLMs

*Part 5 of the LangChain Made Easy series*

Alright, last stop in this series. So far every response we've gotten from a model has been plain text. Fine for a chatbot, but what if you're building something that needs to actually use the model's answer in code? Like filling a database, populating a UI, or feeding another function? Plain text just doesn't cut it there. That's exactly what Structured Output fixes. Let's dig in.

---

## The problem with plain text responses

Let's see what happens when we just ask a model a normal question.

```python
groq_model_name = os.getenv("GROQ_MODEL")
groq_model = init_chat_model(
    os.getenv("GROQ_MODEL"),
    model_provider="groq"
)
unstructured_response = groq_model.invoke("Give me details about the movie 'Jersey' acted by Nani.")
print(unstructured_response.content)
```

You'll get back a paragraph of text describing the movie, its plot, cast, release details, all mixed together in prose. Sounds fine to read, but try extracting just the release year out of that paragraph programmatically. You'd be writing fragile regex or string parsing, and it would break the moment the model phrases things slightly differently next time.

```mermaid
graph LR
    A["Give me details about the movie Jersey"] --> B[Model]
    B --> C["A long paragraph of text"]
    C --> D["You manually parse it and hope it doesn't break"]

    classDef risky fill:#f1100077,stroke:#333,stroke-width:2px;
    class D risky
```

Not great, right? This is exactly the kind of unpredictability that breaks production systems.

---

## The fix: give the model a schema

Instead of hoping the model's text happens to contain what you need, you tell it exactly what shape of data to return. LangChain calls this Structured Output, and the most common way to do it is with `pydantic`.

```mermaid
graph LR
    A["Give me details about the movie Jersey"] --> B["Model + Schema"]
    B --> C["Exact, predictable data object"]
    C --> D["Use it directly in your code"]

    classDef safe fill:#11f00077,stroke:#333,stroke-width:2px;
    class D safe
```

### Step 1: Define your schema with Pydantic

```python
from pydantic import BaseModel, Field

class Movie(BaseModel):
    title: str = Field(..., description="The title of the movie")
    release_year: int = Field(..., description="The year the movie was released")
    genre: str = Field(..., description="The genre of the movie")
```

Notice the `Field(..., description="...")` part. Just like a tool's docstring tells the model when to use it, the description here tells the model exactly what each field means. Don't skip these, they genuinely affect how accurate the output is.

### Step 2: Ask the model to follow that schema

```python
structured_response = groq_model.with_structured_output(Movie).invoke(
    "Give me details about the movie 'Jersey' acted by Nani."
)
structured_response
```

And now, instead of a paragraph, you get back a clean `Movie` object with exactly three fields, `title`, `release_year`, and `genre`. Nothing extra, nothing missing. That's the whole point, predictable output that your code can rely on every single time.

What do you think happens if you need both the raw AI message and the structured data? Turns out, there's an option for that too.

```python
structured_response_with_ai_message = groq_model.with_structured_output(
    Movie, include_raw=True
).invoke("Give me details about the movie 'Jersey' acted by Nani.")
```

Setting `include_raw=True` gives you both, the full `AIMessage` (with metadata, token usage, all of it) and the parsed structured object. Handy when you want the clean data but also want to log or debug the raw response.

---

## Nested structured output

Here's where it gets genuinely useful. Schemas aren't limited to flat fields, you can nest them, just like you'd nest objects in any normal data model.

```python
class Player(BaseModel):
    name: str = Field(..., description="The name of the player")
    role: str = Field(..., description="The role of the player in the team. Ex: Batsman, Bowler, All-rounder, Wicket-keeper, Captain")

class Team(BaseModel):
    name: str = Field(..., description="The name of the team")
    players: list[Player] = Field(..., description="List of players in the team")

structured_response_nested = groq_model.with_structured_output(Team).invoke(
    "Give me best playing 11 of the Indian cricket team in batting order."
)
for player in structured_response_nested.players:
    print(f"{player.name} - {player.role}")
```

Look at what's happening here. `Team` contains a list of `Player` objects, and the model correctly fills in an entire list, each with its own `name` and `role`, all nested inside one clean response. This is genuinely powerful for anything like generating structured reports, populating UI components, or feeding data into another system, all without writing a single parser yourself.

---

## Pydantic isn't the only option

Pydantic gives you the richest feature set, validation, descriptions, and nested structures, but it's not the only way to define a schema. Here's how the three options compare:

| Approach | How you define it | Notes |
|---|---|---|
| Pydantic | Extend `BaseModel`, use `Field(..., description=...)` | Richest features, validation, descriptions, nesting, generally the recommended default |
| TypedDict | Extend `TypedDict`, use `typing.Annotated` for descriptions | Lighter weight, good if you prefer standard typing over Pydantic |
| Dataclass | Use the `@dataclass` decorator | Simple and familiar if you already use dataclasses elsewhere in your code |

The good news? Once you've defined the schema, using it is basically the same regardless of which approach you picked. For `TypedDict` and `Dataclass`, you plug the schema into `create_agent()` using `response_format` instead of calling `.with_structured_output()` directly:

```python
agent = create_agent(
    model=groq_model,
    response_format=Movie   # Movie schema, defined using any of the three approaches
)
```

So really, the only thing that changes across all three approaches is how you write the schema itself. Everything downstream stays the same.

---

## Recap

- Plain text responses are unpredictable and fragile to parse, structured output fixes that.
- Define a schema using Pydantic's `BaseModel` and `Field`, then call `model.with_structured_output(<Schema>)`.
- Use `include_raw=True` if you want both the full AI message and the parsed structured data.
- Schemas can be nested, letting the model return complex, structured objects like a full team of players.
- Pydantic, TypedDict, and Dataclass all work as schema options, only the schema definition changes, everything else stays consistent.

Not bad at all. You've now gone from a single `invoke()` call all the way to building agents that use tools, understand structured conversations, and return clean, predictable data.

---

That wraps up this series. You now have a solid, practical foundation in LangChain, from basic setup, all the way to agents, tools, messages, and structured output. Go build something with it.
