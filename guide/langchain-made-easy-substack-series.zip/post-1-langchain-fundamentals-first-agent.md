# LangChain Fundamentals: Setting Up and Building Your First AI Agent

*Part 1 of the LangChain Made Easy series*

Alright, let's start from zero. No prior LangChain knowledge needed here. I'm going to walk you through this the same way I'd explain it to a friend who just asked me, "hey, what even is LangChain, and why does everyone keep talking about agents?"

By the end of this post, you will have built your very first working AI agent. Let's go.

---

## So, what problem does LangChain actually solve?

Here's the thing. Large Language Models like GPT, Gemini, or Llama are genuinely powerful. But the moment you try to use them inside a real application, things get messy fast. You end up having to handle:

- Connecting to different providers (OpenAI, Google, Groq, and so on)
- Formatting conversation history so the model doesn't lose context
- Letting the model call external tools like APIs or databases
- Parsing whatever the model sends back into something your app can actually use

Now imagine writing all of that from scratch, for every single provider you want to support. Sounds exhausting, right? That is exactly the problem LangChain was built to solve.

**LangChain is basically a framework that hands you ready-made tools and abstractions so you don't have to build all this plumbing yourself.**

Think of it like this:

| Without LangChain | With LangChain |
|---|---|
| Write custom code for each LLM provider | One consistent interface works across all providers |
| Manually manage conversation history | Message objects handle this for you |
| Manually parse tool calls | Tools are handled automatically |
| Reinvent agent logic every time | `create_agent()` gives you a working agent in a few lines |

Makes sense so far? Good. Let's get our hands dirty.

---

## Step one: setting up your project

Before we write a single line of "real" code, let's set up a clean environment. Trust me on this, it will save you headaches later when your projects start piling up and their dependencies start clashing with each other.

We're going to use `uv`, a fast Python package and virtual environment manager.

```bash
# Install uv if you don't have it already
brew install uv
```

Once that's installed, go to your project folder and run:

```bash
# Initialize the project
uv init

# Create a virtual environment
uv venv

# Activate the virtual environment (macOS)
source .venv/bin/activate

# Install the latest version of all dependencies listed in requirements.txt
uv add -r requirements.txt

# Install one specific dependency
uv add ipykernel

# Deactivate the virtual environment when done
deactivate
```

Now you might be wondering, what actually is a virtual environment? In simple terms, it's just an isolated folder that holds all the packages your project needs, kept separate from every other project on your machine. That `.venv` folder you just created? It's basically the same idea as `node_modules` in Node.js or `target` in Java. It just quietly stores your dependencies without mixing them into the rest of your system.

Ok, environment is ready. Now what?

---

## Why do LLMs even need "agents"?

Let's start with the simplest possible Generative AI setup. You give it an input, the LLM processes it, you get an output. That's it.

```mermaid
graph LR
    A["Draft an email to HR (Input)"] --> B[LLM]
    B --> C["Dear HR, I am writing to... (Output)"]
```

This works great when the task only needs the model's existing knowledge. But here's the catch. LLMs have what's called a knowledge cutoff. They simply don't know about anything that happened after their training data ends, and they have zero access to live, real time information.

So watch what happens here:

```mermaid
graph LR
    A["How much did RCB score in today's match? (Input)"] --> B[LLM]
    B --> C["I do not have information about that match. (Output)"]

    classDef output fill:#f1100077,stroke:#333,stroke-width:2px;
    class C output;
```

See the problem? The model just shrugs. It has no idea what happened in today's match because that information didn't exist when it was trained.

So, how do we fix this? Simple. We let the LLM reach outside itself. It calls an API, queries a database, uses some other tool, whatever gets the job done, and brings that fresh information back into the conversation.

```mermaid
graph LR
    A["How much did RCB score in today's match? (Input)"] -- 1 --> B[LLM]
    B -- 2 --> D[External Tool]
    D -- 3 --> E["Fetch real-time data from an API"]
    E -- 4 --> D
    D -- 5 --> B
    B -- 6 --> C["The score is 263/5. (Output)"]

    classDef output fill:#11f00077,stroke:#333,stroke-width:2px;
    class C output;
```

And that, right there, is basically what an Agent is. **An agent is an LLM that can decide, on its own, to reach for an external tool when it needs to.**

It's not just answering from memory anymore. It's making small decisions like:

- Which tool should I use here?
- What information am I still missing?
- How do I combine what the tool gave me into a proper final answer?

Pretty neat, right?

---

## Quick history lesson: agents before LangChain

Before frameworks like LangChain came along, people used a pattern called **ReAct** (short for Reason and Act) to build this "think, use a tool, look at the result, repeat" loop by hand. It worked, sure, but it meant a lot of manual wiring every single time.

LangChain took that whole pattern and squeezed it into one function: `create_agent()`. That's it. Let's actually build one.

---

## Building your first agent

I'm going to break this down into small steps so nothing feels overwhelming.

### Step 1: Check your setup

```python
import langchain, sys

print("LangChain:", langchain.__version__)
print("Python:", sys.version)
print("Executable:", sys.executable)
print("LangChain path:", langchain.__file__)
```

This just confirms LangChain is installed properly and shows you which Python environment you're actually running in. Nothing fancy, just a sanity check.

### Step 2: Load your API keys

Every LLM provider needs an API key so it knows the request is coming from you. Store these in a `.env` file and load them like this:

```python
import os
from dotenv import load_dotenv

load_dotenv(override=True)

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["GOOGLE_API_KEY"] = os.getenv("GOOGLE_API_KEY")
os.environ["GROQ_API_KEY"] = os.getenv("GROQ_API_KEY")
os.environ["MODEL"] = os.getenv("MODEL")
```

One important thing before we move on. Never, ever hardcode your API keys directly into your code. Keep them in a `.env` file, and make sure that file is added to `.gitignore` so it never accidentally ends up on GitHub.

### Step 3: Create an agent with no tools

Let's start simple.

```python
from langchain.agents import create_agent
from langchain_groq import ChatGroq

model = ChatGroq(
    model="openai/gpt-oss-20b",
    api_key=os.environ["GROQ_API_KEY"]
)

agent = create_agent(
    model=model,
    tools=[],   # No tools provided
    system_prompt="You are a helpful assistant."
)
```

At this point, our agent is really just a chatbot wearing an "agent" costume. It has no way of reaching outside its own knowledge. Let's fix that.

### Step 4: Give the agent a tool

```python
def get_weather(location):
    """
    A simple tool to get the weather information for a given location.
    """
    print(f">>> TOOL CALLED for {location}")
    return f"The weather in {location} is sunny with a temperature of 25°C."

agent = create_agent(
    model=model,
    tools=[get_weather],   # Introduce a tool to get weather information
    system_prompt="You are a helpful assistant."
)
```

### Step 5: Run the agent and see what happens

```python
# Query that needs the tool
message_1 = "What is the current condition in Chennai?"
output_1 = agent.invoke({"messages": [{"role": "user", "content": message_1}]})["messages"][-1].content
print(f"Me: {message_1}\nAgent: {output_1}")

# Query that does NOT need the tool
message_2 = "What is the capital of France?"
output_2 = agent.invoke({"messages": message_2})["messages"][-1].content
print(f"Me: {message_2}\nAgent: {output_2}")
```

Here's what's interesting. For the first question, the agent actually calls `get_weather`, because answering it properly needs live, real world data. For the second question, it already knows the answer from training, so it just skips the tool entirely and answers directly.

So basically, the agent is making a judgment call every single time. Cool, right?

---

## Ok but how does the model know which tool to call?

This is probably the most common question beginners ask me at this point. And the answer is refreshingly simple: **the docstring**.

```python
def get_weather(location):
    """
    A simple tool to get the weather information for a given location.
    """
```

That little bit of text inside the triple quotes isn't just there for humans reading your code. The model actually reads it to figure out what the tool does and when it should be used. So writing a clear, accurate docstring isn't optional, it directly affects how well your agent performs.

| Docstring quality | Result |
|---|---|
| Missing or vague | Model may not call the tool at all, or calls the wrong one |
| Clear and specific | Model reliably picks the right tool at the right moment |

What do you think happens if two tools have similar, vague docstrings? Yep, the model gets confused about which one to pick. So take your time writing them well.

---

## You're not limited to just one tool

An agent can juggle multiple tools at once. You just pass a list, and the model figures out which one fits the situation:

```python
agent = create_agent(
    model=model,
    tools=[get_weather, get_stock_price, get_latest_news],
    system_prompt="You are a helpful assistant."
)
```

The model looks at the user's question, compares it against each tool's docstring, and picks whichever one actually fits, or none at all, if the question doesn't need a tool in the first place.

---

## Let's recap what we covered

- LangChain removes the repetitive plumbing of working with LLMs directly.
- Use `uv` to create a clean, isolated environment for your project.
- LLMs have a knowledge cutoff, and agents solve this by calling external tools for live information.
- `create_agent()` builds a working agent in just a few lines of code.
- The tool's docstring is what actually tells the model when and how to use it.

Not bad for a first post, right? You now technically know how to build a working AI agent.

---

**Coming up next:** we're going to look at the three different ways to actually talk to a model, `invoke()`, `stream()`, and `batch()`, and figure out exactly when you'd reach for each one. See you there.
