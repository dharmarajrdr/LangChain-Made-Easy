# Messages: The Language Models Actually Understand

*Part 4 of the LangChain Made Easy series*

So far in this series, we've been calling `model.invoke("some text")` and getting an answer back. That works fine for quick one off questions. But real conversations need more structure than just a plain string. That structure is called a Message, and understanding it properly will make a real difference in how well your agent behaves.

Let's break it down.

---

## What is a message, really?

A message is the basic unit of context that a model works with. Every single message, whether it's from a human, the AI, or a system instruction, is built from three parts:

| Part | What it means |
|---|---|
| Role | Who is "speaking", system, user, or the AI itself |
| Content | The actual text (or image, audio, etc) being sent |
| Metadata | Extra info like timestamps, message IDs, or token usage |

Here's the good part. LangChain gives you one standard message format that works the same way regardless of which provider you're using underneath. So whether it's OpenAI, Gemini, or Groq answering, your code dealing with messages doesn't have to change.

You've actually already seen this without realizing it. Every time you call `.invoke()`, the response you get back isn't just plain text, it's an actual message object.

```python
groq_model.invoke("Hello, how are you?")   # Returns an AIMessage
```

That response has a type, `ai`, because the model generated it. Makes sense, right?

---

## The four message types

LangChain gives you four message types, all available from `langchain.messages`.

```mermaid
graph LR
    A[SystemMessage] -- "Sets behavior/rules" --> D[Model]
    B[HumanMessage] -- "User's question" --> D
    D -- "Generates" --> C[AIMessage]
    D -- "Calls a tool" --> E[ToolMessage]
    E -- "Result goes back to" --> D
```

| Message type | What it represents |
|---|---|
| `SystemMessage` | Tells the model how to behave, its rules, tone, personality |
| `HumanMessage` | A message sent by the actual user |
| `AIMessage` | The model's response to the user |
| `ToolMessage` | The result that comes back from a tool call |

Notice how each one has a clear job. You wouldn't put user input inside a `SystemMessage`, and you wouldn't expect the model's answer to show up as a `HumanMessage`. Keeping these separate is exactly what lets the model understand who said what in a conversation.

---

## Text prompts vs message prompts

Ok, here's where it gets practical. There are two ways to send input to a model, and beginners often don't realize there's a difference.

### Option 1: Text prompts

This is what we've been doing so far, just sending a plain string.

```python
groq_model.invoke("Hello, how are you?")
```

Use this when:

- You want to send a single, standalone message
- You don't care about keeping any conversation history
- You just want a quick, one off response

Simple and fast. But it has no memory of anything before it.

### Option 2: Message prompts

This is where you send a list of messages instead of a single string, giving the model actual context to work with.

```python
from langchain.messages import SystemMessage, HumanMessage

conversation = [
    SystemMessage("You are a helpful assistant. Don't be rude to the user."),
    HumanMessage("Hello!")
]

groq_model.invoke(conversation)
```

Here's what actually comes back when you run this:

```python
AIMessage(
    content='Hello! How can I help you today?',
    additional_kwargs={'reasoning_content': 'The user says "Hello!" The assistant should respond politely.'},
    response_metadata={
        'token_usage': {'completion_tokens': 31, 'prompt_tokens': 89, 'total_tokens': 120, ...},
        'model_name': 'openai/gpt-oss-20b',
        'finish_reason': 'stop', ...
    },
    id='lc_run--019fb61b-cafa-7750-bbe0-82500e8f8576-0',
    tool_calls=[], invalid_tool_calls=[],
    usage_metadata={'input_tokens': 89, 'output_tokens': 31, 'total_tokens': 120, ...}
)
```

Look at all that detail packed into one response. You get the actual `content`, but also `response_metadata` (token counts, which model generated it, why it stopped), and `usage_metadata` (a clean breakdown of input versus output tokens). This is exactly the kind of information you'd want if you're tracking cost or debugging behavior in production.

You'll also notice `reasoning_content` in there, which basically shows how the model interpreted the system prompt before responding. Pretty useful for understanding why the model answered the way it did.

Use message prompts when:

- You need to maintain a proper conversation with history
- You want to set clear rules for how the model should behave
- You're building anything beyond a single throwaway question

---

## Why your system prompt quality actually matters

Here's a small but important detail. The example above showed `reasoning_content` referencing the system prompt directly. That's not a coincidence.

**The more clearly you define your `SystemMessage`, the better and more consistent the model performs.**

| Vague system prompt | Clear system prompt |
|---|---|
| "You are an assistant." | "You are a customer support assistant for an e-commerce app. Be concise, polite, and never make up order details you don't have." |
| Model behavior is inconsistent across runs | Model stays on-brand and predictable |

Think of the system prompt as the model's job description. A vague job description gets vague results. A specific one gets specific, reliable behavior. This is genuinely one of the highest leverage things you can improve in any LLM application, and it costs you nothing extra to write it properly.

---

## Recap

- A message has three parts, role, content, and metadata, and LangChain standardizes this across every provider.
- There are four message types, `SystemMessage`, `HumanMessage`, `AIMessage`, and `ToolMessage`, each with a clear, distinct job.
- Text prompts (plain strings) work for quick, one off questions with no memory needed.
- Message prompts (a list of message objects) are what you use for real conversations with context and history.
- A clear, specific `SystemMessage` genuinely improves how consistent and reliable your model's behavior is.

So basically, once you start thinking in messages instead of plain strings, your agents start feeling a lot more like real conversations instead of disconnected one liners.

---

**Coming up next:** we'll wrap up this series with Structured Output, how to make a model return exactly the data shape you want, instead of a wall of unpredictable text.
