# Invoke, Stream, and Batch: The Three Ways to Talk to an LLM

*Part 2 of the LangChain Made Easy series*

Ok, so in Post 1 we built an agent and got it talking to a model behind the scenes. But we skipped over something pretty important: how do you actually load a model in the first place, and once it's loaded, in how many ways can you actually talk to it?

Turns out, there's more than one way. In this post, we'll cover how to load models from different providers using one single function, and then we'll look at three different ways to call a model, `invoke()`, `stream()`, and `batch()`. Each one fits a different situation, and picking the wrong one can actually hurt your app's user experience. Let's get into it.

---

## Loading a model, the LangChain way

Here's the thing. OpenAI, Google Gemini, and Groq all have their own SDKs, their own quirks, their own way of setting things up. If you were doing this manually, you'd be writing separate code for each one.

LangChain gives you a single function, `init_chat_model()`, that works across all of them. You just tell it which model and which provider, and it handles the rest.

```python
import os
from dotenv import load_dotenv

load_dotenv(override=True)

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["GOOGLE_API_KEY"] = os.getenv("GOOGLE_API_KEY")
os.environ["GROQ_API_KEY"] = os.getenv("GROQ_API_KEY")

from langchain.chat_models import init_chat_model
```

### Loading OpenAI

```python
open_ai_model_name = os.getenv("OPENAI_MODEL")
openai_model = init_chat_model(
    os.getenv("OPENAI_MODEL"),
    model_provider="openai"
)
output1 = openai_model.invoke("Hello, how are you?")
print(f"Output from {open_ai_model_name}: \n{output1.content}")
```

### Loading Google Gemini

```python
%pip install -U langchain-google-genai

google_model_name = os.getenv("GOOGLE_MODEL")
google_model = init_chat_model(
    os.getenv("GOOGLE_MODEL"),
    model_provider="google_genai"
)
output2 = google_model.invoke("Hello, how are you?")
print(f"Output from {google_model_name}: \n{output2.content}")
```

### Loading Groq

```python
groq_model_name = os.getenv("GROQ_MODEL")
groq_model = init_chat_model(
    os.getenv("GROQ_MODEL"),
    model_provider="groq"
)
output3 = groq_model.invoke("Hello, how are you?")
print(f"Output from {groq_model_name}: \n{output3.content}")
```

Notice something? All three blocks look almost identical. Only the model name and `model_provider` change. That's the whole point of `init_chat_model()`, one consistent way to load any provider, so switching providers later is basically a one line change.

So basically, once you learn this pattern once, you know it for every provider LangChain supports. Nice, right?

---

## Now, how do you actually talk to the model?

Once your model is loaded, you have three different methods to get a response out of it: `invoke()`, `stream()`, and `batch()`. Let's go through each one, because picking the right one matters more than you'd think.

```mermaid
graph TD
    A[Model is loaded] --> B{What do you need?}
    B -- "One question, one answer" --> C["invoke()"]
    B -- "Show response as it's typed" --> D["stream()"]
    B -- "Many questions at once" --> E["batch()"]
```

### 1. `invoke()`, the straightforward one

This is what we've been using so far. You send a question, and you wait until the entire response is fully generated, then you get it all at once.

```python
google_model_name = os.getenv("GOOGLE_MODEL")
google_model = init_chat_model(
    os.getenv("GOOGLE_MODEL"),
    model_provider="google_genai"
)
output = google_model.invoke("Hello, how are you?")
print(f"Output from {google_model_name}: \n{output.content}")
```

Simple, but here's the catch. If the response is long, the user just stares at a blank screen until it's fully ready. Not exactly a great experience for something like a chatbot.

### 2. `stream()`, the "type as you go" one

Ever noticed how ChatGPT's answer appears word by word instead of popping up all at once? That's streaming. Most models support this, and LangChain makes it easy to tap into.

```python
for chunk in google_model.stream("How to get a call from Google/Microsoft HR? Please guide under 5 lines."):
    print(chunk.text, end="", flush=True)
# end - Append this at the end of each chunk
# flush - Flush the output buffer to ensure that the text is printed immediately
```

What's happening here? `stream()` returns an iterator, not a single final answer. Every time a new chunk of text is generated, it gets yielded immediately, and your loop prints it right away. The `end=""` keeps everything on the same line instead of adding a new line after every chunk, and `flush=True` makes sure Python prints it instantly instead of holding it in a buffer.

This is what you'd want for any user facing chat interface. Feels faster, even if the total time is the same.

### 3. `batch()`, the "many questions at once" one

What if you have a whole list of questions and you want answers to all of them, without writing a loop and calling `invoke()` five separate times? That's exactly what `batch()` is for.

```python
responses = google_model.batch([
    "Which team won IPL 2026?",
    "Which is the best cricket stadium in India?",
    "How Sanju Samson performed in 2026 World Cup?"
], config = {
    "max_concurrency": 2    # Only 2 requests will be sent to the model at a time. The rest will be queued and sent when one of the previous requests is completed.
})

for response in responses:
    print(response.content)
```

You pass in a list of prompts, and you get back a list of responses, in the same order. The `max_concurrency` setting controls how many requests go out at the same time. Set it to 2, and only 2 questions are being processed simultaneously, the rest wait in a queue until a slot frees up.

Why would you even limit concurrency? Because most providers have rate limits. Fire off fifty requests at once, and you might just get blocked. `max_concurrency` lets you control the pace.

---

## Picking the right one

Here's a quick table to keep handy:

| Method | What you get back | Best used when |
|---|---|---|
| `invoke()` | One complete response, after full generation | Simple scripts, backend logic, quick one off questions |
| `stream()` | Response chunks, as they're generated | Chat interfaces, anything user facing where speed feels important |
| `batch()` | A list of responses, for a list of inputs | Processing many prompts at once, like bulk data generation or evaluation |

There's no universally "best" one here. It genuinely depends on what you're building. A backend script that summarizes a document overnight? `invoke()` is fine. A live chatbot your users are staring at? `stream()` will feel a lot better. Running the same prompt against a hundred different inputs? `batch()` saves you a ton of manual looping.

---

## Recap

- `init_chat_model()` gives you one consistent way to load OpenAI, Gemini, Groq, or any other supported provider.
- `invoke()` waits for the full response and hands it back in one go.
- `stream()` returns the response piece by piece, as it's being generated, great for chat style interfaces.
- `batch()` takes a list of prompts and returns a list of responses, with `max_concurrency` controlling how many run at once.

Ok, now what? You know how to load a model and talk to it in three different ways. Time to make it smarter.

---

**Coming up next:** we're going to look at Messages, the actual format models use to understand a conversation, and why the words you choose in a system prompt matter more than most beginners realize.
